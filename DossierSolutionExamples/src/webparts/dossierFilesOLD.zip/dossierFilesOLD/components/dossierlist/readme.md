# Note
Probably a list component should not be necessary. By starting with a top item, navigation can take place entirely by that interface.