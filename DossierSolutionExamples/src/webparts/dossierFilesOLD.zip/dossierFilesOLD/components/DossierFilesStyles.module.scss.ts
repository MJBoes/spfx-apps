/* tslint:disable */
require("./DossierFilesStyles.module.css");
const styles = {
  webpart: 'webpart_a75af4c2',
  chip: 'chip_a75af4c2',
  descriptionid: 'descriptionid_a75af4c2',
  fabricList: 'fabricList_a75af4c2',
  fabricItemCell: 'fabricItemCell_a75af4c2',
  fabricItemImage: 'fabricItemImage_a75af4c2',
  fabricItemContent: 'fabricItemContent_a75af4c2',
  fabricItemName: 'fabricItemName_a75af4c2',
  fabricItemChevron: 'fabricItemChevron_a75af4c2',
};

export default styles;
/* tslint:enable */