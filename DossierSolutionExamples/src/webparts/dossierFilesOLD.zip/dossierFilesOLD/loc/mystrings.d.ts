declare interface IDossierFilesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DossierFilesWebPartStrings' {
  const strings: IDossierFilesWebPartStrings;
  export = strings;
}
